package com.pwskills.nitin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.pwksills.utility.JdbcUtil;

public class CopyFromOracletoMysqlApp {

	private static final String SQL_INSERT_QUERY = "insert into canarabank(`accno`,`holdername`,`balance`) values(?,?,?)";
	private static final String SQL_SELECT_QUERY = "select accno,holdername,balance from syndicatebank";

	public static void main(String[] args) {

		// Resource used
		Connection mysqlConnection = null;
		Connection oracleConnection = null;
		Statement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultSet = null;

		try {

			oracleConnection = JdbcUtil.getOracleDBConection();
			mysqlConnection = JdbcUtil.getMySQLDBConection();

			if (oracleConnection != null) {
				statement = oracleConnection.createStatement();
			}
			if (mysqlConnection != null) {
				preparedStatement = mysqlConnection.prepareStatement(SQL_INSERT_QUERY);
			}

			if (statement != null) {
				resultSet = statement.executeQuery(SQL_SELECT_QUERY);
			}

			if (resultSet != null && preparedStatement != null) {
				while (resultSet.next()) {

					// Set the values to ? of placeholder
					preparedStatement.setInt(1, resultSet.getInt(1));
					preparedStatement.setString(2, resultSet.getString(2));
					preparedStatement.setFloat(3, resultSet.getFloat(3));

					preparedStatement.executeUpdate();
				}

				System.out.println("Records are copied from OracleDB to MysQLDB....");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// closing resource with OracleDatabase
			JdbcUtil.cleanUpResources(resultSet, statement, oracleConnection);

			// closing resources with MySQLDatabase
			JdbcUtil.cleanUpResources(null, preparedStatement, mysqlConnection);
		}
	}

}
