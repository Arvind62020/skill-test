package com.pwskills.nitin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import com.pwksills.utility.DBUtil;

public class DeleteApp {

	private static final String SQL_DELETE_QUERY = "delete from student where sid = ?";

	public static void main(String[] args) {

		// Resource used
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try {
			connection = DBUtil.getDBConection();

			if (connection != null)
				preparedStatement = connection.prepareStatement(SQL_DELETE_QUERY);

			Scanner scanner = new Scanner(System.in);

			if (scanner != null && preparedStatement != null) {
				System.out.print("Enter the sid:: ");
				int sid = scanner.nextInt();

				preparedStatement.setInt(1, sid);
				System.out.println("No of rows deleted is :: " + preparedStatement.executeUpdate());

				//pausing the application
				System.in.read();
				
				System.out.println("\nReUsing the same PreparedStatement Object to run query with different input");
				System.out.print("Enter the sid:: ");
				sid = scanner.nextInt();
				preparedStatement.setInt(1, sid);
				System.out.println("No of rows deleted is :: " + preparedStatement.executeUpdate());

				scanner.close();
			}

		} catch (IOException | SQLException e) {
			e.printStackTrace();
		} finally {
			DBUtil.cleanUpResources(null, preparedStatement, connection);
		}
	}
}
