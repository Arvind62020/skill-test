package com.pwskills.nitin;

import java.text.SimpleDateFormat;

public class TestApp {

	public static void main(String[] args) throws Exception {

		String indianUser = "03-JAN-1993";
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		java.util.Date utilDate = sdf.parse(indianUser);
		long inputMs = utilDate.getTime();
		java.sql.Date sqlDate = new java.sql.Date(inputMs);
		System.out.println("SQlDate information is :: "+sqlDate);
		
		//Converting to java.sql.Date directly
		String chinaUser = "1993-01-03";
		java.sql.Date sqlOutput = java.sql.Date.valueOf(chinaUser);
		System.out.println("SQLDate information is :: "+sqlOutput);

	}

}
